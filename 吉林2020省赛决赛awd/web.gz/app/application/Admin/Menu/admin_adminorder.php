<?php
return array (
  'app' => 'Admin',
  'model' => 'AdminOrder',
  'action' => 'index',
  'data' => '',
  'type' => '1',
  'status' => '1',
  'name' => '订单管理',
  'icon' => '',
  'remark' => '',
  'listorder' => '0',
  'children' => 
  array (
    array (
      'app' => 'Course',
      'model' => 'AdminOrder',
      'action' => 'index',
      'data' => '',
      'type' => '1',
      'status' => '1',
      'name' => '订单列表',
      'icon' => '',
      'remark' => '',
      'listorder' => '0',
    ),
  ),
);