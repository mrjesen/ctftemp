<?php
namespace Common\Model;
use Common\Model\CommonModel;
class UsercourseModel extends CommonModel{

}