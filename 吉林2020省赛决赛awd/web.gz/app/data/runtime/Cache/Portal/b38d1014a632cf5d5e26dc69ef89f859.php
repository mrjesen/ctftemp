<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html>
<!--<![endif]-->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1">
<meta name="renderer" content="webkit">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title><?php echo ($name); ?> <?php echo ($site_name); ?> <?php echo ($site_seo_title); ?>-Powered by YXTCMF!</title>
<meta name="keywords" content="<?php echo ($site_seo_keywords); ?>" />
<meta name="description" content="<?php echo ($site_seo_description); ?>" />
<link rel="icon" href="/public/simplebootx/public/images/favicon_1409967740.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/public/simplebootx/public/images/favicon_1409967740.ico" type="image/x-icon" media="screen" />
<link href="/public/simplebootx/public/css/bootstrap.css" rel="stylesheet" />
<link rel="stylesheet" media="screen" href="/public/simplebootx/public/css/common.css" />
<link rel="stylesheet" media="screen" href="/public/simplebootx/public/css/main.css" />
<link rel="stylesheet" media="screen" href="/public/simplebootx/public/css/es-icon.css" />
<link rel="stylesheet" media="screen" href="/public/simplebootx/public/css/iconfont.css" />
<link href="/public/simpleboot/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" media="screen" href="/public/simplebootx/public/css/theme.css" />
<link href="/public/js/artDialog/skins/default.css" rel="stylesheet" />
<!--[if lt IE 9]>    
	<script src="/public/simplebootx/public/js/html5shiv.js"></script>   
	<script src="/public/simplebootx/public/js/respond.min.js"></script>  
<![endif]-->
</head>
<body>	
	<header class="navbar">		
		<div class="container">			
			<div class="clearfix navbar-top">				
				<a href="/"><img src="/public/simplebootx/public/images/logo.png" class="pull-left logo-left"></a>				
				<button class="navbar-toggle pull-left" type="button" data-toggle="collapse" data-target=".navbar-collapse">		
					<span class="sr-only">Toggle navigation</span>			
					<span class="icon-bar"><i class="iconfont icon-gengduo"></i></span>		
					<span class="icon-bar"></span>				
					<span class="icon-bar"></span>				
				</button>				
				<form class="navbar-form hidden-xs" role="search" action="<?php echo u('Course/Course/search');?>" method="post">					
					<div class="form-group">					
						<input type="search" placeholder="搜索课程" class="form-control js-search" name="keywords">				
					</div>					
					<button type="submit" class="button iconfont icon-search"></button>				
				</form>				
				<a class="pull-right hidden-xs">					
					<i class="iconfont icon-mianfeidianhua icon"></i>				
					<span class="telephone">全国服务热线：<?php echo ($kefu_tel); ?></span>			
				</a>			
				<div class="navbar-user pull-right visible-xs"  style="top:16px;" >					
				<?php if(session('?user')): ?><ul class="nav navbar-nav navbar-right">														
						<li class="info-img">
							<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"> 		
								<span><?php echo ($user_nicename); ?></span> <i class="iconfont icon-xia"></i> 
							</a>								
									<ul class="dropdown-menu menu-ul" role="menu">									
										<li><a href="<?php echo u('User/Center/setting');?>">
											<i class="iconfont icon-shezhi"></i>个人设置</a></li>										
										<li><a href="<?php echo u('user/center/count');?>"><i class="iconfont icon-001"></i> 账户中心</a></li>										
											<li><a href="<?php echo u('user/center/application');?>"><i class="iconfont icon-001"></i> 成为教师</a></li>								
										<li><a href="<?php echo U('user/index/logout');?>"><i class="iconfont icon-tuichu"></i>退出登录</a></li>									
									</ul>								
						</li>					
					</ul>					
				<?php else: ?>						
					<ul class="nav navbar-nav navbar-right">							
						<li><a href="<?php echo leuu('User/Login/index');?>"> 登录</a></li>							
						<li>｜</li>							
						<li><a href="<?php echo leuu('User/Register/index');?>">注册</a></li>			
					</ul><?php endif; ?>				
				</div>			
			</div>		
		</div>		
		<nav class="nav-collapse">			
			<div class="container">				
				<div class="navbar-header">					
					<ul class="nav navbar-left navbar-collapse collapse">						
						<li class=""><a href="/" class="">首页 </a></li>						
						<li class=""><a href="<?php echo leuu('Course/Course/coursecenter');?>" class="">精品课程</a></li>						
						<li class=""><a href="<?php echo leuu('Teacher/Teacher/index');?>" class="">金牌讲师</a></li>						
						<li class=""><a href="<?php echo leuu('Exam/Shiti/index');?>" class="">在线题库</a></li>						
						<li class=""><a href="<?php echo leuu('Portal/Index/article');?>" class="">文章资讯</a></li>						
						<li class=""><a href="<?php echo leuu('Forum/Plate/index');?>" class="">交流论坛</a></li>						
						<?php if(is_array($nav)): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class=""><a href="<?php echo (sp_get_href($vo['href'])); ?>" class=""><?php echo ($vo['label']); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>					
					</ul>				
				</div>				
				<div class="navbar-user hidden-xs">				
					<ul class="nav navbar-nav navbar-right">						
					<?php if(session('?user')): ?><ul class="nav navbar-nav navbar-right">							
							<?php if($user_type == 3): ?><li><a href="<?php echo u('Teacher/Center/index');?>" class="nav-study">我的教室</a></li>							
							<?php else: ?>								
								<li><a href="<?php echo u('User/Center/index');?>" class="nav-study">我的教室</a></li><?php endif; ?>								
								<li class="info-img">
									<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"> 				
										<?php if(empty($avatar)): ?><img src="/public/simplebootx/public/images/093958e59110293063.jpg" class="img-circle" />		
										<?php else: ?> 										
											<img src="<?php echo sp_get_user_avatar_url($avatar);?>?t=<?php echo time();?>" class="img-circle" /><?php endif; ?> 									
										<span><?php echo ($user_nicename); ?></span> <i class="iconfont icon-xia"></i> 
									</a>									
									<ul class="dropdown-menu menu-ul" role="menu">								
										<li><a href="<?php echo u('User/Center/setting');?>"><i class="iconfont icon-shezhi"></i>个人设置</a></li>		
										<li><a href="<?php echo u('user/center/count');?>"><i class="iconfont icon-001"></i> 账户中心</a></li>	
										<li><a href="<?php echo u('user/center/application');?>"><i class="iconfont icon-001"></i> 成为教师</a></li>	
										<li><a href="<?php echo U('user/index/logout');?>"><i class="iconfont icon-tuichu"></i>退出登录</a></li>	
									</ul>								
								</li>						
						</ul>					
					<?php else: ?>				
						<ul class="nav navbar-nav navbar-right">							
							<li><a href="<?php echo leuu('User/Login/index');?>"> <span class="glyphicon glyphicon-log-in"></span>&nbsp&nbsp登录</a></li>	
							<li><a href="<?php echo leuu('User/Register/index');?>"><span class="glyphicon glyphicon-user"></span>&nbsp&nbsp注册</a></li>	
						</ul><?php endif; ?>					
					</ul>				
				</div>			
			</div>		
		</nav>    
	</header>         
    <section class="poster hidden-xs">
      <div id="carousel" class="carousel slide" data-ride="carousel">
       <ol class="carousel-indicators">
        <?php if(is_array($slide)): $$key = 0; $__LIST__ = $slide;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($$key % 2 );++$$key; if($key == 0): ?><li data-target="#carousel" data-slide-to="<?php echo ($key); ?>" class="active"></li>
          <?php else: ?>
             <li data-target="#carousel" data-slide-to="<?php echo ($key); ?>" class=""></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>  
      </ol>
      <div class="carousel-inner" role="listbox">
        <?php if(is_array($slide)): $$key = 0; $__LIST__ = $slide;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($$key % 2 );++$$key; if($key == 0): ?><div class="item active">
             <a href="<?php echo ($vo['slide_url']); ?>" target="_self"><img src="<?php echo sp_get_asset_upload_path($vo['slide_pic']);?>" alt="<?php echo ($vo['slide_des']); ?>"></a>
            </div>
          <?php else: ?>
            <div class="item">
             <a href="<?php echo ($vo['slide_url']); ?>" target="_self"><img src="<?php echo sp_get_asset_upload_path($vo['slide_pic']);?>" alt="<?php echo ($vo['slide_des']); ?>"></a>
            </div><?php endif; endforeach; endif; else: echo "" ;endif; ?>  
      </div>
       <a class="left carousel-control hidden-xs" href="#carousel" role="button" data-slide="prev">
         <i class="iconfont icon-jiantou3 carousel-left"></i>
       </a>
       <a class="right carousel-control hidden-xs" href="#carousel" role="button" data-slide="next">
         <i class="iconfont icon-jiantou4 carousel-right"></i>
       </a>
     </div>
    </section>
	<div class="some_total  hidden-xs" >
		<div class="warp  hidden-xs">
			<ul class="col-md-12">
				<li class="col-md-3"><i class="icon_1"></i><div><span class="num">10<sup>+</sup><sub>个</sub></span><span>在线专业总数</span></div></li>
				<li class="col-md-3"><i class="icon_2"></i><div><span class="num">2000<sup>+</sup><sub>个</sub></span><span>在线视频总数</span></div></li>
				<li class="col-md-3"><i class="icon_3"></i><div><span class="num">20000<sup>+</sup><sub>小时</sub></span><span>在线课程时长</span></div></li>
				<li class="last col-md-3"><i class="icon_4"></i><div><span class="num">20000000<sup>+</sup><sub>次</sub></span><span>视频点击总量</span></div></li>
			</ul>
		</div>
	</div>
    <section class="index-course-list lazyload">
      <div class="container">
	    <div class="text-line  hidden-xs">
            <h5><span>精品网校课程</span><div class="line"></div></h5>
            <div class="subtitle">精选网校课程，满足你的学习需求。</div>
          </div>
        <div class="es-filter">
          <ul id="myTab" class="nav clearfix nav-tabs">
            <li class="active"><a href="#zuixin" data-toggle="tab">最新</a></li>
            <li><a href="#tuijian" data-toggle="tab">推荐</a></li>
            <li><a href="#free" data-toggle="tab">免费</a></li>
          </ul>
        </div>
        <div id="myTabContent" class="tab-content">
         <div class="tab-pane fade in active row item  course-list" id="zuixin">
          <?php if(is_array($zx_courselist)): $i = 0; $__LIST__ = $zx_courselist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="col-lg-3 col-md-4 col-xs-6">
             <div class="course-item">
                <div class="course-img">
					  <a href="<?php echo leuu('course/Course/courseinfo',array('id'=>$vo['id']));?>">
					  
					     <?php if(empty($vo['cs_picture'])): ?><img class="transform img-responsive " src="/public/images/course.png">
						 <?php else: ?> 
						   <img class="transform img-responsive "  src="<?php echo ($vo['cs_picture']); ?>"><?php endif; ?> 
						
						
						<?php if($vo['course_type']=='live'): ?><span class="tags">
							   <span class="tag-live"></span>
							</span>
						<?php else: ?> 
							 <?php if($vo['isover']==0): ?><span class="tags">
								    <span class="tag-serialing"></span>
								</span>
							 <?php else: ?>
							    <span class="tags">
								    <span class="tag-finished"></span>
								</span><?php endif; endif; ?>
						<div class="course-show clearfix">
						 <?php if(empty($vo['tpic'])): ?><img src="/public/simplebootx/public/images/defult.jpg" class="img-circle pull-left">
						 <?php else: ?> 
						   <img src="<?php echo sp_get_user_avatar_url($vo['tpic']);?>?t=<?php echo time();?>" class="img-circle  pull-left" /><?php endif; ?> 
							<div class="pull-left">
							  <h4><?php echo ($vo['teacher']); ?></h4>
							  <p><?php echo ($vo['cs_name']); ?></p>
							</div>
						 </div>
					  </a>
                 </div>
                 <div class="course-info">
                   <div class="title"><a href="<?php echo leuu('course/Course/courseinfo',array('id'=>$vo['id']));?>"><?php echo ($vo['cs_name']); ?></a></div>
                    <div class="metas clearfix">
                      <span class="num"><i class="es-icon es-icon-people"></i><?php echo ($vo['xueyuannum']); ?>人在学</span>
					  <span class="comment"><i class="es-icon es-icon-textsms"></i><?php echo ($vo['pinglununm']); ?></span>
					  <?php if(!$vo['cs_price']==0): ?><span class="price price-num">¥<?php echo ($vo['cs_price']); ?>.00</span> 
					 <?php else: ?> 
					     <span class="price price-num text-success">免费</span><?php endif; ?>						
                    </div>
                  </div>
                </div>
              </div><?php endforeach; endif; else: echo "" ;endif; ?>       
           </div>
           <div class="tab-pane fade  item row item course-list" id="tuijian">
             <?php if(is_array($tuijian_courselist)): $i = 0; $__LIST__ = $tuijian_courselist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="col-lg-3 col-md-4 col-xs-6">
                <div class="course-item">
                 <div class="course-img">
                  <a href="<?php echo leuu('course/Course/courseinfo',array('id'=>$vo['id']));?>">
				        <?php if(empty($vo['cs_picture'])): ?><img class="transform img-responsive " src="/public/images/course.png">
						 <?php else: ?> 
						   <img class="transform img-responsive "  src="<?php echo ($vo['cs_picture']); ?>"><?php endif; ?> 
				        <?php if($vo['course_type']=='live'): ?><span class="tags">
							   <span class="tag-live"></span>
							</span>
						<?php else: ?> 
							 <?php if($vo['isover']==0): ?><span class="tags">
								    <span class="tag-serialing"></span>
								</span>
							 <?php else: ?>
							    <span class="tags">
								    <span class="tag-finished"></span>
								</span><?php endif; endif; ?> 
                    <div class="course-show clearfix">
                      <?php if(empty($vo['tpic'])): ?><img src="/public/simplebootx/public/images/1803026e1ab3793901.JPG" class="img-circle pull-left">
					 <?php else: ?> 
					   <img src="<?php echo sp_get_user_avatar_url($vo['tpic']);?>?t=<?php echo time();?>" class="img-circle  pull-left" /><?php endif; ?> 
                        <div class="pull-left">
                          <h4><?php echo ($vo['teacher']); ?></h4>
                          <p><?php echo ($vo['cs_name']); ?></p>
                        </div>
                     </div>
                  </a>
                 </div>
                 <div class="course-info">
                   <div class="title"><a href="<?php echo leuu('course/Course/courseinfo',array('id'=>$vo['id']));?>"><?php echo ($vo['cs_name']); ?></a></div>
                     <div class="metas clearfix">
                      <span class="num"><i class="es-icon es-icon-people"></i><?php echo ($vo['xueyuannum']); ?>人在学</span>
					  <span class="comment"><i class="es-icon es-icon-textsms"></i><?php echo ($vo['pinglununm']); ?></span>
                      <?php if(!$vo['cs_price']==0): ?><span class="price price-num">¥<?php echo ($vo['cs_price']); ?>.00</span> 
					 <?php else: ?> 
					     <span class="price price-num text-success">免费</span><?php endif; ?>		                       
                    </div>
                  </div>
                </div>
               </div><?php endforeach; endif; else: echo "" ;endif; ?>   
           </div>
           <div class="tab-pane fade  item row item course-list" id="free">
             <?php if(is_array($free_courselist)): $i = 0; $__LIST__ = $free_courselist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="col-lg-3 col-md-4 col-xs-6">
                <div class="course-item">
                 <div class="course-img">
                  <a href="<?php echo leuu('course/Course/courseinfo',array('id'=>$vo['id']));?>">
				        <?php if(empty($vo['cs_picture'])): ?><img class="transform img-responsive " src="/public/images/course.png">
						 <?php else: ?> 
						   <img class="transform img-responsive "  src="<?php echo ($vo['cs_picture']); ?>"><?php endif; ?> 
				        <?php if($vo['course_type']=='live'): ?><span class="tags">
							   <span class="tag-live"></span>
							</span>
						<?php else: ?> 
							 <?php if($vo['isover']==0): ?><span class="tags">
								    <span class="tag-serialing"></span>
								</span>
							 <?php else: ?>
							    <span class="tags">
								    <span class="tag-finished"></span>
								</span><?php endif; endif; ?>
                    <div class="course-show clearfix">
                      <?php if(empty($vo['tpic'])): ?><img src="/public/simplebootx/public/images/1803026e1ab3793901.JPG" class="img-circle pull-left">
					 <?php else: ?> 
					   <img src="<?php echo sp_get_user_avatar_url($vo['tpic']);?>?t=<?php echo time();?>" class="img-circle  pull-left" /><?php endif; ?> 
                        <div class="pull-left">
                          <h4><?php echo ($vo['teacher']); ?></h4>
                          <p><?php echo ($vo['cs_name']); ?></p>
                        </div>
                     </div>
                  </a>
                 </div>
                 <div class="course-info">
                   <div class="title"><a href="<?php echo leuu('course/Course/courseinfo',array('id'=>$vo['id']));?>"><?php echo ($vo['cs_name']); ?></a></div>
                     <div class="metas clearfix">
                      <span class="num"><i class="es-icon es-icon-people"></i><?php echo ($vo['xueyuannum']); ?>人在学</span>
					  <span class="comment"><i class="es-icon es-icon-textsms"></i><?php echo ($vo['pinglununm']); ?></span>
                      <?php if(!$vo['cs_price']==0): ?><span class="price price-num">¥<?php echo ($vo['cs_price']); ?>.00</span> 
					 <?php else: ?> 
					     <span class="price price-num text-success">免费</span><?php endif; ?>		                        
                    </div>
                  </div>
                </div>
               </div><?php endforeach; endif; else: echo "" ;endif; ?>   
           </div>
         </div>
         
      </div>
      </section>
	  <section class="recommend-teacher">
		<div class="container">
			<div class="text-line">
				<h5><span>金牌讲师</span><div class="line"></div></h5>
				<div class="subtitle">名师汇集，保证教学质量与学习效果。</div>
			</div>
			<div class="row">
			    <?php if(is_array($teacherlist)): $i = 0; $__LIST__ = $teacherlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="col-md-3 col-xs-6">
						<div class="teacher-item">
							<div class="teacher-top">
								<a class="teacher-img" href="<?php echo u('Teacher/Teacher/about',array('id'=>$vo['id']));?>">
								    <?php if(empty($vo['avatar'])): ?><img src="/public/simplebootx/public/images/093958e59110293063.jpg" class="img-circle" style="max-width:150px;width:150px;"/>
									<?php else: ?> 
										<img src="<?php echo sp_get_user_avatar_url($vo['avatar']);?>" class="img-circle" style="max-width:150px;width:150px;"/><?php endif; ?>
								</a>
								<h3 class="title">
									<a class="link-dark" href="<?php echo u('Teacher/Teacher/about',array('id'=>$vo['id']));?>"><?php echo ($vo['user_nicename']); ?></a>
								</h3>
								<div class="position">
									<?php echo ((isset($vo['zhicheng']) && ($vo['zhicheng'] !== ""))?($vo['zhicheng']):"该教师没有设置！"); ?>
								</div>
							</div>
							<div class="teacher-bottom">
								<div class="about">
									<?php echo ((isset($vo['signature']) && ($vo['signature'] !== ""))?($vo['signature']):"该教师没有设置！"); ?>
								</div>
								<div class="metas">
									<a class="btn btn-primary btn-sm follow-btn" href="<?php echo u('Teacher/Teacher/about',array('id'=>$vo['id']));?>">进入教师中心</a>
								</div>
							</div>
						</div>
					</div><?php endforeach; endif; else: echo "" ;endif; ?>	
			</div>
			<div class="section-more-btn">
				<a href="<?php echo u('Teacher/Teacher/index');?>" class="btn btn-default btn-lg">
					更多教师 <i class="mrs-o es-icon es-icon-chevronright"></i>
				</a>
			</div>
        </div>
     </section>
     <section class="index-introduction hidden-xs">
       <div id="carousel" class="carousel slide" data-ride="carousel">
       <ol class="carousel-indicators">
        <?php if(is_array($mslide)): $$key = 0; $__LIST__ = $mslide;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($$key % 2 );++$$key; if($key == 0): ?><li data-target="#carousel" data-slide-to="<?php echo ($key); ?>" class="active"></li>
          <?php else: ?>
             <li data-target="#carousel" data-slide-to="<?php echo ($key); ?>" class=""></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>  
      </ol>
      <div class="carousel-inner" role="listbox">
        <?php if(is_array($mslide)): $$key = 0; $__LIST__ = $mslide;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($$key % 2 );++$$key; if($key == 0): ?><div class="item active">
             <a href="<?php echo ($vo['slide_url']); ?>" target="_self"><img src="<?php echo sp_get_asset_upload_path($vo['slide_pic']);?>" alt="<?php echo ($vo['slide_des']); ?>"></a>
            </div>
          <?php else: ?>
            <div class="item">
             <a href="<?php echo ($vo['slide_url']); ?>" target="_self"><img src="<?php echo sp_get_asset_upload_path($vo['slide_pic']);?>" alt="<?php echo ($vo['slide_des']); ?>"></a>
            </div><?php endif; endforeach; endif; else: echo "" ;endif; ?>  
      </div>
     </div>
     </section>
     <?php if(!empty($articlelist)): ?><section class="group-dynamic clearfix">
        <div class="container">
         <?php if(is_array($articlelist)): $k = 0; $__LIST__ = $articlelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?><div class="col-md-4">
            <div class="course_sy2 ">
                 <div class="opb3"><?php echo ($vo['name']); ?><div class=" mor11"><a href="<?php echo u('Portal/Index/article',array('termid'=>$vo['term_id']));?>">更多&gt;</a></div></div>
               <?php if(is_array($vo['voo'])): $k = 0; $__LIST__ = $vo['voo'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$sub): $mod = ($k % 2 );++$k;?><div class="course_sy3b op3"><a href="<?php echo u('Portal/Index/content',array('id'=>$sub['id'],'termid'=>$sub['term_id']));?>" target="_blank" title=""><?php echo ($sub['post_title']); ?></a></div><?php endforeach; endif; else: echo "" ;endif; ?>
        	</div>
           </div><?php endforeach; endif; else: echo "" ;endif; ?>  
        </div>
      </section><?php endif; ?>
<script type="text/javascript">
var GV = {
    DIMAUB: "/",
    JS_ROOT: "public/js/",
    TOKEN: ""
};
</script>
<script>
	  
</script>
<script src="/public/js/jquery.js"></script>
<script src="/public/js/wind.js"></script>
<script src="/public/js/bootstrap.min.js"></script>
<script src="/public/js/frontend.js"></script>
<script src="/public/js/artDialog/artDialog.js"></script>
  <div class="es-footer-link">
   <div class="container">
     <div class="row">
       <div class="col-md-12 footer-main clearfix">
       <?php if(is_array($dnav)): $i = 0; $__LIST__ = $dnav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="link-item ">
           <h3><?php echo ($vo['label']); ?></h3>
           <ul>
            <?php if(is_array($vo['voo'])): $i = 0; $__LIST__ = $vo['voo'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$sub): $mod = ($i % 2 );++$i;?><li><a href="<?php echo (sp_get_href($sub['href'])); ?>" target="_blank"><?php echo ($sub['label']); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
           </ul>
         </div><?php endforeach; endif; else: echo "" ;endif; ?>  
     </div>
    </div>
	<div class="fr_link">
	  <div class="yq_lk">
	     <h3>友情链接</h3>
		 <?php if(is_array($links)): $i = 0; $__LIST__ = $links;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><a href="<?php echo ($vo['link_url']); ?>"  target="<?php echo ($vo['link_target']); ?>" title="<?php echo ($vo['link_name']); ?>"><?php echo ($vo['link_name']); ?></a><?php endforeach; endif; else: echo "" ;endif; ?> 
	  </div>
	</div>       
  </div>
 </div>
<footer class="es-footer">
  <div class="copyright">
    <div class="container">Powered by <a href="/" target="_blank"><?php echo ($site_name); ?></a>©2016-2018 <a class="mlm" href="/" target="_blank"></a>      
       <div class="mts">课程内容版权均归<a href="/"><?php echo ($site_name); ?>文化传播有限公司</a>
           所有<a class="mlm" href="http://www.miibeian.gov.cn/" target="_blank"><?php echo ($site_icp); ?></a><?php echo ($site_tongji); ?>
       </div>
       
    </div>
  </div>
</footer>    
</body>
</html>