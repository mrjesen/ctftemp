<?php	return array (
  'login$' => 'user/login/index',
  'register$' => 'user/register/index',
  'course$' => 'course/course/coursecenter',
  'about$' => 'portal/page/index?id=1',
  'forum$' => 'forum/plate/index',
  'article' => 'portal/index/article',
  'courseinfo/:id\d' => 'course/course/courseinfo',
);