<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'yxtcmf',
    'DB_USER' => 'admin',
    'DB_PWD' => 'admin567',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'yxt_',
//密钥
    "AUTHCODE" => 'XvwL6pUlc3g8mvcpYS',
//cookies
    "COOKIE_PREFIX" => 'QcAcba_',
);
