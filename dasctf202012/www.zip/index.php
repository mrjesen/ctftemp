<?php
header("Location: public");