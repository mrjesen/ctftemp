This should be moved to separate package, like `yii\yii2-cs`.
