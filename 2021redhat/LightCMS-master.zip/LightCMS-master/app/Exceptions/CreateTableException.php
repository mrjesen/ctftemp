<?php

namespace App\Exceptions;

use RuntimeException;

class CreateTableException extends RuntimeException
{
}
