<?php

namespace App\Model\Admin;

class SensitiveWord extends Model
{
    protected $guarded = [];
}
