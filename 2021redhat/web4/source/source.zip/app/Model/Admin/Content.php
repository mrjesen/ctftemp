<?php
/**
 * @author  Eddy <cumtsjh@163.com>
 */

namespace App\Model\Admin;

class Content extends Model
{
    protected $guarded = [];
}
