<?php
/**
 * @author  Eddy <cumtsjh@163.com>
 */

namespace App\Model\Admin;

class ContentTag extends Model
{
    protected $guarded = [];
}
