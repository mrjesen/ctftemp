@extends('admin.base')

@section('title', '内容管理')

@section('content')

@endsection

@section('js')
    <script>
    </script>
@endsection